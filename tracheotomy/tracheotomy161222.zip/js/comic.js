//let the complete shitshow begin, i cannot code to save my life so this should be interesting

//stolen code from Rarebit lmao
let pg = Number(findGetParameter("pg"));




console.log(pg);

 

document.getElementById("pageimage").innerHTML = `<img src="${pagelist[pg].ImgUrl}} />`



function findGetParameter(parameterName) { //function used to write a parameter to append to the url, to give each comic page its own unique url
    let result = null,
    tmp = []; 
    let items = location.search.substr(1).split("&");
    for (let index = 0; index < items.length; index++) {
        tmp = items[index].split("=");
        if (tmp[0] === parameterName) result = decodeURIComponent(tmp[1]);
    }
    return result;
}
	