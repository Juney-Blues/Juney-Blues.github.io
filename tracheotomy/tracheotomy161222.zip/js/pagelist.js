
var pageList = [
				{
					"pgNum": "0", 
					"imgUrl": "https://64.media.tumblr.com/9c40c03f7ae2e763750601ca914bda0f/31db3c3a98d36c54-0f/s1280x1920/ad58171e049b1870fee1819d235d4714d5269bb8.png"
				},
				{
					"pgNum": "1", 
					"imgUrl": "https://64.media.tumblr.com/e988453228915768f738de5904d3834f/e18a4e65a965cfd5-26/s1280x1920/ea1fe13fecbd261009eae36887463a69a71d5dae.gif"
				},
				{
					"pgNum": "2", 
					"imgUrl": "https://64.media.tumblr.com/2dc59fef4a363c8679448af744f8415e/e18a4e65a965cfd5-19/s1280x1920/0109fa8a7da496e1fc18b4966aa8cad5d0442701.png"
				},
				{
					"pgNum": "3", 
					"imgUrl": "https://64.media.tumblr.com/61997ca295f9bc773ebc82b7ba0fac09/e18a4e65a965cfd5-b5/s1280x1920/9a7bffe9d0adf55399daa06154ac9bebd712ef38.png"
				},
]

