//let the complete shitshow begin, i cannot code to save my life so this should be interesting

//stolen code from Rarebit lmao
let currentPage = Number(findGetParameter("pg"));

nextPage = currentPage + 1;
	prevPage = currentPage - 1;




console.log(currentPage);
console.log(nextPage);
console.log(prevPage);
console.log(pageList.length);

document.getElementById("pageimage").innerHTML = `<img src="${pageList[currentPage].imgUrl}" />`;






function findGetParameter(parameterName) { //function used to write a parameter to append to the url, to give each comic page its own unique url
    let result = null,
    tmp = []; 
    let items = location.search.substr(1).split("&");
    for (let index = 0; index < items.length; index++) {
        tmp = items[index].split("=");
        if (tmp[0] === parameterName) result = decodeURIComponent(tmp[1]);
    }
    return result;
}
	
function next()
{

	if (nextPage > pageList.length - 1){
		nextPage = currentPage;
	}
		
	window.location.href = `?pg=${nextPage}`;

}

function prev()
{

		if (prevPage < 0){
		prevPage = currentPage;
	}
	window.location.href = `?pg=${prevPage}`;
	
}

function setPageLinks(pg) {
  document.querySelector(".nextpage").href = "?pg=" + (pg + 1)
  document.querySelector(".prevpage").href = "?pg=" + (pg - 1)

  if (pg - 1 < 0) { document.querySelector(".prevpage").style.display = "none" }
  else { document.querySelector(".prevpage").style.display = "unset" }

  if (pg + 1 < pageList.Length) { document.querySelector(".nextpage").style.display = "none" }
  else { document.querySelector(".nextpage").style.display = "unset" }
}

setPageLinks(pg);
