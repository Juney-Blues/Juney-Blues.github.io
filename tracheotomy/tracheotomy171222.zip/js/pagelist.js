
const pageList = [
				{
					"pgNum": "0", 
					"imgUrl": "https://file.garden/Y5hdfT_qkQx7G08g/Tracheotomy/Chapter1Part1/watchasiperformmyowntracheotomy.png",
					"date":writeDate(2022, 10, 26),
				},
				{
					"pgNum": "1", 
					"imgUrl": "https://file.garden/Y5hdfT_qkQx7G08g/Tracheotomy/Chapter1Part1/Ch1Pg1.gif",
					"date":writeDate(2022, 10, 8),
				},
				{
					"pgNum": "2", 
					"imgUrl": "https://file.garden/Y5hdfT_qkQx7G08g/Tracheotomy/Chapter1Part1/Ch1Pg2.png",
					"date":writeDate(2022, 10, 8),
				},
				{
					"pgNum": "3", 
					"imgUrl": "https://file.garden/Y5hdfT_qkQx7G08g/Tracheotomy/Chapter1Part1/Ch1Pg3.png",
					"date":writeDate(2022, 10, 8),
				},
				{
					"pgNum": "4", 
					"imgUrl": "https://file.garden/Y5hdfT_qkQx7G08g/Tracheotomy/Chapter1Part1/Ch1Pg4.png",
					"date":writeDate(2022, 10, 9),
				},
				{
					"pgNum": "5", 
					"imgUrl": "https://file.garden/Y5hdfT_qkQx7G08g/Tracheotomy/Chapter1Part1/Ch1Pg5.png",
					"date":writeDate(2022, 10, 9),
				},
				{
					"pgNum": "6", 
					"imgUrl": "https://file.garden/Y5hdfT_qkQx7G08g/Tracheotomy/Chapter1Part1/Ch1Pg6.png",
					"date":writeDate(2022, 10, 8),
				},
				{
					"pgNum": "7", 
					"imgUrl": "https://file.garden/Y5hdfT_qkQx7G08g/Tracheotomy/Chapter1Part1/Ch1Pg7.png",
					"date":writeDate(2022, 10, 11),
				},
				{
					"pgNum": "8", 
					"imgUrl": "https://file.garden/Y5hdfT_qkQx7G08g/Tracheotomy/Chapter1Part1/Ch1Pg8.png",
					"date":writeDate(2022, 10, 13),
				},
				{
					"pgNum": "9", 
					"imgUrl": "https://file.garden/Y5hdfT_qkQx7G08g/Tracheotomy/Chapter1Part1/Ch1Pg9.png",
					"date":writeDate(2022, 10, 13),
				},
				{
					"pgNum": "10", 
					"imgUrl": "https://file.garden/Y5hdfT_qkQx7G08g/Tracheotomy/Ch1pt2/Ch1Pg10.png",
					"date":writeDate(2022, 11, 8),
				},
				{
					"pgNum": "11", 
					"imgUrl": "https://file.garden/Y5hdfT_qkQx7G08g/Tracheotomy/Ch1pt2/Ch1Pg11.png",
					"date":writeDate(2022, 11, 8),
				},
				{
					"pgNum": "12", 
					"imgUrl": "https://file.garden/Y5hdfT_qkQx7G08g/Tracheotomy/Ch1pt2/Ch1Pg12.png",
					"date":writeDate(2022, 11, 9),
				},
				{
					"pgNum": "13", 
					"imgUrl": "https://file.garden/Y5hdfT_qkQx7G08g/Tracheotomy/Ch1pt2/Ch1Pg13.png",
					"date":writeDate(2022, 11, 9),
				},
				{
					"pgNum": "14", 
					"imgUrl": "https://file.garden/Y5hdfT_qkQx7G08g/Tracheotomy/Ch1pt2/Ch1Pg14.png",
					"date":writeDate(2022, 11, 12),
				},
				{
					"pgNum": "15", 
					"imgUrl": "https://file.garden/Y5hdfT_qkQx7G08g/Tracheotomy/Ch1pt2/Ch1Pg15Actual.gif",
					"date":writeDate(2022, 11, 12),
				},
				{
					"pgNum": "16", 
					"imgUrl": "https://file.garden/Y5hdfT_qkQx7G08g/Tracheotomy/Ch1pt2/Ch1Pg16.png",
					"date":writeDate(2022, 11, 23),
				},
				{
					"pgNum": "17", 
					"imgUrl": "https://file.garden/Y5hdfT_qkQx7G08g/Tracheotomy/Ch1pt2/Ch1Pg17.png",
					"date":writeDate(2022, 12, 3),
				},
]

function writeDate(year,month,day) { //write date of comic page
    const date = new Date(year,month-1,day)
    .toDateString() //format date as Day Month Date Year
    .toString() //convert it to a string
    .slice(4) //remove the Day
    return date
}